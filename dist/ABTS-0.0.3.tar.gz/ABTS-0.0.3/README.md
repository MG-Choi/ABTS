# ABTS
Agent Based Travel Scheduler library to predict individual travel schedules


## License
ABTS / version 0.1.1
- install: